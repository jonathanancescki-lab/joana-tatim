import json, os, subprocess, sys, colorsys
from PIL import Image, ImageStat
SRC='crops'; OUT='site/media'
meta={}
for f in sorted(os.listdir(SRC)):
    k=f[:-4]; im=Image.open(f'{SRC}/{f}').convert('RGB'); w,h=im.size
    if w/h < 0.75:
        nh=int(w*4/3); top=(h-nh)//2; im=im.crop((0,top,w,top+nh))
    else:
        nw=int(h*0.75); l=(w-nw)//2; im=im.crop((l,0,l+nw,h))
    big=im.resize((900,1200),Image.LANCZOS)
    big.save(f'{OUT}/posters/{k}-900.webp',quality=78,method=6)
    big.resize((450,600),Image.LANCZOS).save(f'{OUT}/posters/{k}-450.webp',quality=72,method=6)
    big.save(f'/tmp/{k}-src.png')
    # ambient color: mean of a 24px border
    sm=big.resize((90,120)); px=[sm.getpixel((x,y)) for x in range(90) for y in range(120) if x<4 or x>85 or y<4 or y>115]
    amb=tuple(sum(c[i] for c in px)//len(px) for i in range(3))
    meta[k]='#%02x%02x%02x'%amb
    # placeholder preview video: slow push-in + soft brown-noise room tone (test only)
    subprocess.run(['ffmpeg','-y','-loglevel','error','-loop','1','-i',f'/tmp/{k}-src.png',
      '-f','lavfi','-i','anoisesrc=color=brown:amplitude=0.06:sample_rate=44100',
      '-filter_complex',"[0:v]scale=1800:2400,zoompan=z='1+0.0009*on':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=150:s=720x960:fps=25,format=yuv420p[v];[1:a]lowpass=f=900,afade=t=in:d=0.6,afade=t=out:st=5.4:d=0.6[a]",
      '-map','[v]','-map','[a]','-t','6','-c:v','libx264','-preset','veryfast','-crf','27','-profile:v','high',
      '-c:a','aac','-b:a','64k','-movflags','+faststart',f'{OUT}/video/{k}-preview.mp4'],check=True)
    print(k, meta[k])
json.dump(meta,open('colors.json','w'),indent=1)
