// Gera dist/: um index.html com CSS e JS embutidos (para hospedagem de arquivo único)
// + a pasta media/. Uso: node scripts/build.mjs
import { readFileSync, writeFileSync, mkdirSync, cpSync, rmSync } from 'node:fs';
import { build } from 'esbuild';

const SRC = 'site';
const OUT = 'dist';
rmSync(OUT, { recursive: true, force: true });
mkdirSync(OUT, { recursive: true });

let page = readFileSync(`${SRC}/index.html`, 'utf8');

page = page.replace(/<link rel="stylesheet" href="(assets\/css\/[^"]+)">\n?/g, (_, href) =>
  `<style>/* ${href} */\n${readFileSync(`${SRC}/${href}`, 'utf8')}</style>\n`);

const js = await build({
  entryPoints: [`${SRC}/assets/js/main.js`],
  bundle: true, format: 'iife', target: 'es2020', minify: true, write: false, legalComments: 'none',
});
page = page.replace(/<script type="module" src="assets\/js\/main.js"><\/script>/,
  () => `<script>${js.outputFiles[0].text.replace(/<\/script/gi, '<\\/script')}</script>`);

writeFileSync(`${OUT}/index.html`, page);
cpSync(`${SRC}/media`, `${OUT}/media`, { recursive: true });
console.log('dist/index.html', (page.length / 1024).toFixed(1) + ' KB');
