# Portfólio Joana Tatim · vídeos sensoriais

Site estático em HTML, CSS e JavaScript puros (ES modules), sem framework e sem dependências em produção.

```
site/                      ← código-fonte (abra com um servidor local)
  index.html
  assets/css/tokens.css    ← paleta, tipografia, espaços e movimento (tokens)
  assets/css/base.css      ← reset, utilitários, botões, placeholder
  assets/css/components/   ← um arquivo por componente
  assets/js/main.js        ← monta tudo, roteamento por hash
  assets/js/data/          ← CONTEÚDO: site.js, projects.js, taxonomy.js
  assets/js/core/media-controller.js  ← lazy load, autoplay, som, movimento
  assets/js/components/    ← header, hero, featured, work-index, viewer, process, cta, contact, footer
  media/posters/           ← pôsteres WebP 450w e 900w
  media/video/             ← vídeos (hoje: PRÉVIAS geradas dos prints)
scripts/build.mjs          ← gera dist/ com CSS e JS embutidos
scripts/media.py           ← como as prévias e os pôsteres foram gerados
```

Rodar localmente: `python3 -m http.server --directory site` e abrir http://localhost:8000.
Gerar a versão de arquivo único: `npm i && node scripts/build.mjs` (saída em `dist/`).

---

## Antes de publicar

1. **Trocar as prévias pelos vídeos originais.** Hoje cada vídeo é um "push-in" lento do quadro recortado do print, com um ruído suave de teste no lugar do áudio. Os arquivos ficam em `media/video/` e o caminho está em `projects.js`.
2. **Preencher os placeholders.** Todo dado que falta aparece como `[texto]` com fundo amarelo. A barra "rascunho" (canto inferior esquerdo) conta quantos são e destaca todos. Depois, desligue a barra com `site.draft = false` em `data/site.js`.
3. **Validar a copy sugerida.** No código, ela está marcada com `// COPY SUGERIDA` (lede do topo, etapas do processo, CTA).
4. **Confirmar com cada marca** a autorização para exibir os trabalhos.

### Lista de placeholders

| Onde | O que falta |
|---|---|
| `site.reel` | reel oficial de 30 a 60 s (hoje usa "matéria-prima em estado líquido") |
| `site.about.photo` / `site.about.bio` | foto de perfil e bio curta |
| `site.contact.whatsapp` | WhatsApp comercial |
| `site.contact.responseTime` | prazo de resposta |
| `site.contact.city` | cidade-base para gravações presenciais |
| `site.contact.email` | confirmar se o e-mail da bio é o comercial |
| `projects[].sound` | descrição do som de cada vídeo (acessibilidade) |
| `projects[].media.carouselNote` | demais fotos dos carrosséis de bastidores |
| `rose-inspired.music` | licença da trilha para uso fora do Instagram |
| bloco "marcas nos trabalhos" | autorização de uso das marcas |

## Vídeos: formato e performance

Para cada projeto, exporte um corte sem barras e sem interface do Instagram e gere:

```bash
# H.264 (todos os navegadores)
ffmpeg -i original.mov -vf "scale=1080:-2" -c:v libx264 -preset slow -crf 23 -profile:v high \
  -c:a aac -b:a 128k -movflags +faststart media/video/<id>.mp4
# VP9 (menor; o navegador escolhe o primeiro formato que suporta)
ffmpeg -i original.mov -vf "scale=1080:-2" -c:v libvpx-vp9 -b:v 0 -crf 34 -row-mt 1 \
  -c:a libopus -b:a 96k media/video/<id>.webm
# Pôsteres (quadro de referência)
ffmpeg -ss 1.5 -i original.mov -frames:v 1 quadro.png   # depois gere 450w e 900w em WebP
```

Em `projects.js`, coloque o `.webm` antes do `.mp4` em `media.sources`, apague `placeholder: true` e use `ratio: '9 / 16'` quando o vídeo for vertical. Na grade o quadro recorta em 3:4; no viewer ele aparece inteiro.

Como a página carrega os vídeos:

- Nenhum vídeo baixa antes de chegar perto da tela. As `<source>` usam `data-src` e `preload="none"`, e o `MediaController` só preenche o `src` quando o quadro está a cerca de 300 px da área visível.
- O pôster é um `<img>` com `srcset` e `loading="lazy"`. Só o pôster do topo usa `fetchpriority="high"`.
- O vídeo toca quando metade do quadro está visível e pausa fora da tela, com a aba oculta ou com o viewer aberto.
- Na grade, o vídeo só toca ao passar o mouse ou dar foco. No celular, a grade mostra apenas os pôsteres.
- Não há autoplay quando o sistema pede menos movimento ou quando o navegador está em modo de economia de dados (Save-Data).

## Som e acessibilidade

- O som começa sempre desligado. O botão "som" do cabeçalho liga o som do vídeo mais visível. O botão de som de cada quadro escolhe aquele vídeo. Só um vídeo toca com som por vez.
- O botão "movimento" pausa toda a reprodução automática (WCAG 2.2.2). A escolha fica guardada durante a sessão.
- Cada quadro tem botão de pausa. O viewer tem play/pausa, barra de posição e som.
- Atalhos do viewer: ← → para navegar, espaço ou K para pausar, M para o som, Esc para fechar.
- O viewer usa `<dialog>` modal, que prende o foco. Ao fechar, o foco volta ao card de origem.
- Há link "pular para o conteúdo", foco sempre visível, filtros com rádios nativos e o resultado do filtro anunciado por `aria-live`.
- Texto alternativo: cada projeto tem `alt` (o que se vê), mostrado também no viewer.
- **Legendas.** Se algum vídeo tiver fala, adicione um `.vtt` em `projects[].tracks`, por exemplo `{ src: 'media/captions/<id>.vtt', srclang: 'pt-BR', label: 'português' }`. Ele vira `<track kind="captions" default>`.
- Contraste: o texto de metadados tem 6.4:1 sobre o fundo. No viewer, a cor do texto é calculada a partir da cor de cada projeto.

## Formulário de orçamento

O site é estático. Ao enviar, o formulário valida os campos e monta a mensagem; a pessoa então escolhe "abrir no e-mail" (mailto preenchido) ou "copiar mensagem". Para receber direto, troque o `submit` em `components/contact.js` por um POST a um serviço de formulários (Formspree, Netlify Forms, Basin). O botão "quero algo nessa linha", no viewer, já preenche o projeto de referência.

## Tokens

Todos ficam em `assets/css/tokens.css`. Os principais:

- Fundo: papel de estúdio `--color-paper`.
- Texto: `--color-ink` e `--color-ink-soft`.
- `--color-rec`: luz de REC, usada só para "som ligado".
- Fontes:
  - Newsreader (display, usada com parcimônia);
  - Hanken Grotesk (texto);
  - Geist Mono (metadados, como em uma claquete).
- Escala tipográfica `--step--1` a `--step-5` e espaços `--space-1` a `--space-8`.

Cada projeto também tem um `tint`, a cor ambiente amostrada do próprio quadro. Ele tinge as seções de destaque e o viewer, então a cor do site vem do trabalho dela.

---

## Pesquisa que orientou o projeto

1. **Vídeo sensorial funciona antes da palavra.** Ganchos de textura e som prendem a atenção antes de qualquer argumento, e beleza e bebidas são os setores que mais usam o formato. → O vídeo vem primeiro e o texto fica na margem.
2. **O briefing do nicho fala de som, textura, ritmo e cadência.** → Cada projeto mostra a legenda original e tem um campo "som".
3. **A experiência é mais forte com fones de ouvido** (Journal of Advertising Research, 2023). → O som tem controle visível e há um convite a ouvir de fone.
4. **ASMR divide o público, e o efeito varia por categoria de produto** (Esade; Hasselt University). → O som começa desligado e o portfólio é filtrável por categoria de marca.
5. **No Brasil, a experiência sensorial ganha força** com as texturas mousse e jelly e com a tendência gourmand. Esse é o cruzamento do trabalho da Joana (mousse benvi, chocolate Suplemind, cafés Giói).
6. **Como portfólios de vídeo costumam funcionar.** Uma frase de posicionamento, um reel curto e de 3 a 6 destaques. A meta é que o reel seja visto e que o visitante entre em contato. Os trabalhos se agrupam por tipo de entrega.
7. **Técnica.** Autoplay só com `muted` e `playsinline`, lazy load por IntersectionObserver com pôster, e nada de lazy no vídeo do topo (web.dev, Chrome for Developers). O WCAG 2.2.2 exige um meio de pausar movimento que dure mais de 5 s.

**Referência htbpw.com.** Só foi possível ler o HTML da página, não a página renderizada. A linguagem extraída e adaptada:

- fundo branco;
- navegação curta, só com rótulos de texto;
- grade de imagens sem legenda, que falam sozinhas;
- formatos verticais e horizontais misturados;
- rótulos em minúsculas.

O que foi aplicado:

- texto todo em minúsculas;
- navegação de três itens;
- grade com ritmo variado (itens grandes ocupam 2 colunas);
- metadados mínimos em mono.

Tipografia exata, transições e espaçamento da referência não foram verificados. Ajuste os tokens se quiser se aproximar mais dela.
