import { icons } from '../utils/icons.js';
import { storage } from '../utils/dom.js';

/**
 * MediaController
 * Coordena todos os quadros de vídeo do site.
 *
 *  - Lazy load: as <source data-src> só recebem src quando o quadro chega a ~300px da tela.
 *  - Autoplay silencioso: toca quando ≥50% do quadro está visível; pausa fora da tela,
 *    com a aba oculta ou com o viewer aberto.
 *  - Som: começa desligado. Ligado, só o quadro mais visível (ou o escolhido) toca com som.
 *  - Movimento: respeita prefers-reduced-motion e Save-Data; a pessoa pode pausar tudo
 *    pelo botão "movimento" no cabeçalho (WCAG 2.2.2).
 *  - Modo "hover": prévia muda ao passar o mouse ou focar (só em dispositivos com hover).
 *
 * Eventos: dispara "change" (detail: { soundOn, motionOn }) a cada mudança de estado global.
 */
export class MediaController extends EventTarget {
  constructor() {
    super();
    this.frames = new Map();
    this.soundOn = false;
    this.preferred = null;
    this.active = null;
    this.suspended = false;

    const reduce = matchMedia('(prefers-reduced-motion: reduce)');
    const saveData = !!navigator.connection?.saveData;
    const stored = storage.get('jt-motion');
    this.motionOn = stored ? stored === 'on' : !(reduce.matches || saveData);
    this.canHover = matchMedia('(hover: hover) and (pointer: fine)').matches;

    reduce.addEventListener?.('change', (e) => { if (e.matches) this.setMotion(false); });

    this.loadObserver = new IntersectionObserver(
      (entries) => entries.forEach((e) => {
        if (e.isIntersecting) { this.load(e.target); this.loadObserver.unobserve(e.target); }
      }),
      { rootMargin: '300px 0px' },
    );

    this.playObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          const s = this.frames.get(e.target);
          if (s) s.ratio = e.isIntersecting ? e.intersectionRatio : 0;
        });
        this.sync();
      },
      { threshold: [0, 0.25, 0.5, 0.75, 1] },
    );

    document.addEventListener('visibilitychange', () => this.sync());
  }

  /** Registra todos os [data-media] ainda não registrados dentro de root. */
  register(root = document) {
    root.querySelectorAll('[data-media]').forEach((frame) => this.add(frame));
  }

  add(frame) {
    if (this.frames.has(frame)) return;
    const video = frame.querySelector('video');
    if (!video) return; // quadro só com imagem (bastidores)

    const s = { video, mode: frame.dataset.autoplay || 'visible', ratio: 0, userPaused: false, userPlay: false, loaded: false };
    this.frames.set(frame, s);

    video.addEventListener('playing', () => { frame.dataset.state = 'playing'; this.updateFrameUI(frame); });
    video.addEventListener('pause', () => {
      if (frame.dataset.state !== 'unavailable' && s.mode !== 'hover') frame.dataset.state = s.loaded ? 'paused' : 'idle';
      this.updateFrameUI(frame);
    });
    const sources = video.querySelectorAll('source');
    sources[sources.length - 1]?.addEventListener('error', (e) => {
      // <source> sem src (antes do lazy load) também dispara "error": ignorar.
      if (!s.loaded || !e.target.getAttribute('src')) return;
      frame.dataset.state = 'unavailable';
      console.warn('[media] vídeo indisponível:', sources[0]?.dataset.src);
    });

    frame.querySelector('[data-role="play"]')?.addEventListener('click', () => this.togglePlay(frame));
    frame.querySelector('[data-role="sound"]')?.addEventListener('click', () => this.toggleSoundFor(frame));

    if (s.mode === 'visible') {
      this.loadObserver.observe(frame);
      this.playObserver.observe(frame);
    } else if (s.mode === 'hover') {
      const root = frame.closest('[data-hover-root]') || frame;
      const start = () => {
        if (!this.canHover || !this.motionOn || this.suspended) return;
        this.load(frame);
        video.muted = true;
        this.play(video);
      };
      const stop = () => { video.pause(); frame.dataset.state = 'idle'; };
      root.addEventListener('pointerenter', start);
      root.addEventListener('pointerleave', stop);
      root.addEventListener('focusin', start);
      root.addEventListener('focusout', stop);
    }
    this.updateFrameUI(frame);
  }

  load(frame) {
    const s = this.frames.get(frame);
    if (!s || s.loaded) return;
    s.video.querySelectorAll('source[data-src]').forEach((src) => { src.src = src.dataset.src; });
    s.video.preload = 'auto';
    s.video.load();
    s.loaded = true;
  }

  play(video) {
    const p = video.play();
    if (p?.catch) {
      p.catch(() => {
        // Autoplay com som bloqueado pelo navegador: volta para mudo e tenta de novo.
        if (!video.muted) { video.muted = true; video.play().catch(() => {}); }
      });
    }
  }

  /** Decide o que toca, o que pausa e qual quadro tem som. */
  sync() {
    const visibleFrames = [...this.frames].filter(([, s]) => s.mode === 'visible');

    const candidates = visibleFrames.filter(([, s]) => s.ratio >= 0.5 && !s.userPaused);
    const pref = this.preferred && this.frames.get(this.preferred);
    this.active = pref && pref.ratio >= 0.25 && !pref.userPaused
      ? this.preferred
      : candidates.sort((a, b) => b[1].ratio - a[1].ratio)[0]?.[0] ?? null;

    for (const [frame, s] of visibleFrames) {
      const inView = s.ratio >= 0.5 || (frame === this.active && s.ratio > 0);
      const shouldPlay = !document.hidden && !this.suspended && inView && !s.userPaused && (this.motionOn || s.userPlay);
      s.video.muted = !(this.soundOn && frame === this.active);
      if (shouldPlay) { this.load(frame); if (s.video.paused) this.play(s.video); }
      else if (!s.video.paused) s.video.pause();
      this.updateFrameUI(frame);
    }

    if (this.suspended) {
      for (const [, s] of this.frames) if (s.mode === 'hover' && !s.video.paused) s.video.pause();
    }

    this.dispatchEvent(new CustomEvent('change', { detail: { soundOn: this.soundOn, motionOn: this.motionOn } }));
  }

  updateFrameUI(frame) {
    const s = this.frames.get(frame);
    if (!s) return;
    const playBtn = frame.querySelector('[data-role="play"]');
    const soundBtn = frame.querySelector('[data-role="sound"]');
    if (playBtn) {
      const playing = !s.video.paused;
      playBtn.innerHTML = String(playing ? icons.pause : icons.play);
      playBtn.setAttribute('aria-label', playing ? 'pausar vídeo' : 'reproduzir vídeo');
    }
    if (soundBtn) {
      const on = this.soundOn && frame === this.active;
      soundBtn.innerHTML = String(on ? icons.soundOn : icons.soundOff);
      soundBtn.setAttribute('aria-pressed', String(on));
      soundBtn.setAttribute('aria-label', on ? 'desligar o som' : 'ligar o som deste vídeo');
    }
  }

  togglePlay(frame) {
    const s = this.frames.get(frame);
    if (!s) return;
    if (s.video.paused) { s.userPaused = false; s.userPlay = true; this.load(frame); this.play(s.video); }
    else { s.userPaused = true; s.userPlay = false; s.video.pause(); }
    this.sync();
  }

  toggleSoundFor(frame) {
    const s = this.frames.get(frame);
    if (!s) return;
    if (this.soundOn && this.active === frame) { this.setSound(false); return; }
    this.preferred = frame;
    s.userPaused = false;
    s.userPlay = true;
    this.soundOn = true;
    this.sync(); // dentro do clique: o navegador permite tocar com som
  }

  setSound(on) { this.soundOn = on; this.sync(); }

  setMotion(on) {
    this.motionOn = on;
    storage.set('jt-motion', on ? 'on' : 'off');
    if (!on) for (const [, s] of this.frames) s.userPlay = false;
    this.sync();
  }

  /** Pausa a galeria enquanto o viewer está aberto. */
  suspend(value) { this.suspended = value; this.sync(); }
}
