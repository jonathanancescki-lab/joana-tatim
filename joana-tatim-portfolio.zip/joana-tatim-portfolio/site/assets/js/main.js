/**
 * Ponto de entrada. Monta os componentes a partir dos dados, liga o controle de mídia,
 * o viewer e o roteamento por hash (#inicio, #trabalhos, #processo, #contato, #projeto-<id>).
 */
import { site } from './data/site.js';
import { sortedProjects, byId } from './data/projects.js';
import { categories, formats } from './data/taxonomy.js';
import { mount, qs } from './utils/dom.js';
import { MediaController } from './core/media-controller.js';
import { Header, bindHeader, setCurrentNav } from './components/header.js';
import { Hero } from './components/hero.js';
import { Featured } from './components/featured.js';
import { WorkIndex, bindWorkIndex } from './components/work-index.js';
import { Process } from './components/process.js';
import { Cta } from './components/cta.js';
import { Contact, bindContact } from './components/contact.js';
import { Footer } from './components/footer.js';
import { Viewer } from './components/viewer.js';
import { mountDraftBar } from './components/draft-bar.js';

const media = new MediaController();

// -- Montagem ---------------------------------------------------------------
const header = mount('#site-header', Header({ site }));
mount('#hero', Hero({ site, project: byId(site.reel.projectId) }));
mount('#destaques-mount', Featured({ projects: site.featured.map(byId).filter(Boolean) }));
const workIndex = mount('#trabalhos-mount', WorkIndex({ projects: sortedProjects, categories, formats }));
mount('#processo-mount', Process({ site }));
mount('#cta-mount', Cta());
const contactEl = mount('#contato-mount', Contact({ site, categories, projects: sortedProjects }));
mount('#site-footer', Footer({ site }));

bindHeader(header, media);
bindWorkIndex(workIndex, { projects: sortedProjects, media });
const contact = bindContact(contactEl, { site, byId });
media.register(document);

const viewer = new Viewer(qs('#viewer'), {
  projects: sortedProjects,
  media,
  onQuote: (id) => contact.prefill(id),
});

document.addEventListener('click', (e) => {
  const opener = e.target.closest('[data-open]');
  if (opener) { e.preventDefault(); viewer.open(opener.dataset.open, opener); }
});

if (site.draft) mountDraftBar(qs('#draft-bar'));

// -- Rotas por hash ---------------------------------------------------------
const TITLES = {
  inicio: 'Portfólio Joana Tatim',
  contato: 'Orçamentos · Joana Tatim',
};
let currentView = null;

function showView(name) {
  if (name === currentView) return false;
  document.querySelectorAll('[data-view]').forEach((v) => { v.hidden = v.dataset.view !== name; });
  setCurrentNav(header, name);
  document.title = TITLES[name];
  const changed = currentView !== null;
  currentView = name;
  media.sync();
  return changed;
}

function route() {
  const hash = decodeURIComponent(location.hash.slice(1));
  if (hash === 'contato') {
    if (viewer.isOpen) viewer.close();
    if (showView('contato')) { window.scrollTo(0, 0); qs('#contato-title').focus({ preventScroll: true }); }
    return;
  }
  const changed = showView('inicio');
  if (hash.startsWith('projeto-')) { viewer.open(hash.slice(8)); return; }
  if (viewer.isOpen) viewer.close();
  const target = hash && hash !== 'inicio' ? document.getElementById(hash) : null;
  if (target) target.scrollIntoView();
  else if (changed || hash === 'inicio') { window.scrollTo(0, 0); qs('#hero-title').focus({ preventScroll: true }); }
}

window.addEventListener('hashchange', route);
route();
