import { html } from '../utils/dom.js';
import { icons } from '../utils/icons.js';

export function Cta() {
  return html`<section class="wrap" aria-labelledby="cta-title">
    <div class="cta">
      <div>
        <h2 class="cta__title" id="cta-title">seu produto tem uma textura que a foto não mostra?</h2>
        <p class="cta__text">conte sobre o produto e o que a marca quer que as pessoas sintam ao assistir.</p>
      </div>
      <a class="btn" href="#contato">pedir orçamento ${icons.arrow}</a>
    </div>
  </section>`;
}
