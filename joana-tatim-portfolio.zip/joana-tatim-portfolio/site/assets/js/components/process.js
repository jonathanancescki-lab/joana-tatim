import { html, txt } from '../utils/dom.js';

export function Process({ site }) {
  return html`<section class="process wrap" id="processo" aria-labelledby="processo-title">
    <header class="section-head">
      <p class="mono section-head__label">processo</p>
      <h2 class="section-head__title" id="processo-title">do produto na mão ao som do vídeo</h2>
    </header>

    <ol class="steps">
      ${site.process.map((s, i) => html`<li class="step">
        <span class="mono step__num">${String(i + 1).padStart(2, '0')}</span>
        <h3 class="step__title">${s.title}</h3>
        <p class="step__text">${s.text}</p>
      </li>`)}
    </ol>

    <div class="about">
      <div class="about__photo mono">${txt(site.about.photo)}</div>
      <div class="about__body">
        <p class="mono soft">sobre</p>
        <p class="about__bio">${txt(site.about.bio)}</p>
        <div>
          <p class="mono soft" style="margin-bottom: var(--space-3)">formatos entregues</p>
          <ul class="formats">${site.formats.map((f, i) => html`<li><span class="mono soft">${String(i + 1).padStart(2, '0')}</span><span>${f}</span></li>`)}</ul>
        </div>
      </div>
    </div>
  </section>`;
}
