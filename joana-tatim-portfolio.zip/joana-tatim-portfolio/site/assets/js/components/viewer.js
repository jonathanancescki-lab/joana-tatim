import { html, mount, txt, timecode, mixHex, luminance, isPlaceholder } from '../utils/dom.js';
import { icons } from '../utils/icons.js';
import { labelOf, categories, formats } from '../data/taxonomy.js';

const PAPER = '#f2f2ef';
const INK = '#121211';

/** Cores do viewer a partir da cor ambiente do projeto, com contraste garantido. */
function themeFor(tint) {
  const bg = mixHex(tint, PAPER, 0.62);
  const dark = luminance(bg) < 0.22;
  return {
    bg,
    fg: dark ? PAPER : INK,
    soft: dark ? mixHex(PAPER, bg, 0.78) : mixHex(INK, bg, 0.78),
  };
}

/**
 * Viewer de projeto em tela cheia (<dialog> modal: foco preso e Esc nativos).
 * Teclado: ← → navegam, espaço ou K pausa/toca, M liga/desliga o som, Esc fecha.
 * Link direto: #projeto-<id>.
 */
export class Viewer {
  constructor(dialog, { projects, media, onQuote }) {
    this.dialog = dialog;
    this.projects = projects;
    this.media = media;
    this.onQuote = onQuote;
    this.index = -1;
    this.trigger = null;
    this.prevHash = '';

    dialog.className = 'viewer';
    dialog.setAttribute('aria-labelledby', 'viewer-title');
    mount(dialog, html`<div class="viewer__inner">
      <div class="viewer__bar">
        <p class="mono viewer__count" data-counter></p>
        <button class="icon-btn viewer__close" type="button" data-close aria-label="fechar projeto">${icons.close}</button>
      </div>
      <div class="viewer__stage">
        <button class="icon-btn viewer__nav" type="button" data-step="-1" aria-label="projeto anterior">${icons.prev}</button>
        <div class="viewer__frame" data-frame data-state="idle">
          <img class="viewer__poster" data-poster alt="">
          <video class="viewer__video" data-video playsinline loop preload="metadata" aria-hidden="true" tabindex="-1"></video>
          <p class="mono viewer__unavailable" data-unavailable hidden>vídeo indisponível. confira o arquivo em media/video.</p>
        </div>
        <button class="icon-btn viewer__nav" type="button" data-step="1" aria-label="próximo projeto">${icons.next}</button>
        <div class="viewer__controls" data-controls>
          <button class="icon-btn" type="button" data-role="play" aria-label="pausar vídeo">${icons.pause}</button>
          <input class="viewer__seek" type="range" min="0" max="1000" step="1" value="0" data-seek aria-label="posição do vídeo" aria-valuetext="00:00">
          <span class="mono viewer__time" data-time>00:00 / 00:00</span>
          <button class="icon-btn" type="button" data-role="sound" aria-pressed="false" aria-label="ligar o som">${icons.soundOff}</button>
        </div>
      </div>
      <aside class="viewer__panel" data-panel></aside>
    </div>`);

    this.$ = (sel) => dialog.querySelector(sel);
    this.video = this.$('[data-video]');
    this.frame = this.$('[data-frame]');
    this.seek = this.$('[data-seek]');
    this.bindEvents();
  }

  bindEvents() {
    const { dialog, video } = this;
    this.$('[data-close]').addEventListener('click', () => this.close());
    dialog.querySelectorAll('[data-step]').forEach((b) => b.addEventListener('click', () => this.step(+b.dataset.step)));
    this.$('[data-role="play"]').addEventListener('click', () => this.togglePlay());
    this.$('[data-role="sound"]').addEventListener('click', () => this.media.setSound(!this.media.soundOn));

    // Clique fora do conteúdo (no ::backdrop) fecha
    dialog.addEventListener('click', (e) => { if (e.target === dialog) this.close(); });
    dialog.addEventListener('close', () => this.afterClose());
    dialog.addEventListener('cancel', (e) => { e.preventDefault(); this.close(); });

    dialog.addEventListener('keydown', (e) => {
      const onControl = e.target.matches('input, select, textarea') || (e.target.matches('button, a') && (e.key === ' ' || e.key === 'Enter'));
      if (e.key === 'ArrowRight' && !e.target.matches('input')) { e.preventDefault(); this.step(1); }
      else if (e.key === 'ArrowLeft' && !e.target.matches('input')) { e.preventDefault(); this.step(-1); }
      else if ((e.key === ' ' || e.key.toLowerCase() === 'k') && !onControl) { e.preventDefault(); this.togglePlay(); }
      else if (e.key.toLowerCase() === 'm' && !e.target.matches('input, textarea')) { this.media.setSound(!this.media.soundOn); }
    });

    video.addEventListener('playing', () => { this.frame.dataset.state = 'playing'; this.renderControls(); });
    video.addEventListener('pause', () => { this.frame.dataset.state = 'paused'; this.renderControls(); });
    video.addEventListener('timeupdate', () => this.renderTime());
    video.addEventListener('loadedmetadata', () => this.renderTime());
    video.addEventListener('error', () => { this.$('[data-unavailable]').hidden = false; });
    this.seek.addEventListener('input', () => {
      if (Number.isFinite(video.duration)) video.currentTime = (this.seek.value / 1000) * video.duration;
    });

    // Gesto de arrastar no celular
    let x0 = null;
    this.frame.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; }, { passive: true });
    this.frame.addEventListener('touchend', (e) => {
      if (x0 == null) return;
      const dx = e.changedTouches[0].clientX - x0;
      if (Math.abs(dx) > 50) this.step(dx < 0 ? 1 : -1);
      x0 = null;
    });

    this.media.addEventListener('change', () => {
      if (!this.dialog.open) return;
      this.video.muted = !this.media.soundOn;
      this.renderControls();
    });

    this.dialog.addEventListener('click', (e) => {
      const q = e.target.closest('[data-quote]');
      if (q) { this.close({ toHash: 'contato' }); this.onQuote?.(q.dataset.quote); }
    });
  }

  get current() { return this.projects[this.index]; }
  get isOpen() { return this.dialog.open; }

  open(id, trigger = null) {
    const i = this.projects.findIndex((p) => p.id === id);
    if (i < 0) return;
    if (!this.dialog.open) {
      this.trigger = trigger || document.activeElement;
      this.prevHash = location.hash.startsWith('#projeto-') ? '' : location.hash;
      this.media.suspend(true);
      this.dialog.showModal();
    }
    this.show(i);
    this.$('[data-close]').focus();
  }

  step(delta) {
    if (!this.dialog.open) return;
    this.show((this.index + delta + this.projects.length) % this.projects.length);
  }

  show(i) {
    this.index = i;
    const p = this.current;
    const t = themeFor(p.tint);
    this.dialog.style.setProperty('--v-bg', t.bg);
    this.dialog.style.setProperty('--v-fg', t.fg);
    this.dialog.style.setProperty('--v-soft', t.soft);
    this.frame.style.setProperty('--ratio', p.media.ratio || 'var(--frame-ratio)');

    history.replaceState(null, '', `#projeto-${p.id}`);
    this.$('[data-counter]').textContent = `${p.number} / ${String(this.projects.length).padStart(2, '0')} · ${p.title}`;

    const poster = this.$('[data-poster]');
    poster.src = `${p.media.poster}-900.webp`;
    poster.alt = p.alt;

    const v = this.video;
    v.pause();
    v.removeAttribute('src');
    v.replaceChildren();
    this.$('[data-unavailable]').hidden = true;
    this.frame.dataset.state = 'idle';
    const hasVideo = p.media.sources.length > 0;
    this.$('[data-controls]').hidden = !hasVideo;

    if (hasVideo) {
      p.media.sources.forEach((s) => {
        const el = document.createElement('source');
        el.src = s.src; el.type = s.type;
        el.addEventListener('error', () => { this.$('[data-unavailable]').hidden = false; });
        v.append(el);
      });
      (p.tracks || []).forEach((tr, k) => {
        const el = Object.assign(document.createElement('track'), { kind: tr.kind || 'captions', src: tr.src, srclang: tr.srclang || 'pt-BR', label: tr.label || 'português', default: k === 0 });
        v.append(el);
      });
      v.muted = !this.media.soundOn;
      v.load();
      const play = v.play();
      play?.catch?.(() => { if (!v.muted) { v.muted = true; v.play().catch(() => {}); } });
    }

    this.renderPanel(p);
    this.renderControls();
    this.renderTime();

    // Pré-carrega o pôster do próximo
    const next = this.projects[(i + 1) % this.projects.length];
    new Image().src = `${next.media.poster}-900.webp`;
  }

  renderPanel(p) {
    const meta = [
      ['marca', p.brands.length ? p.brands.join(', ') : 'projeto autoral'],
      ['categoria', labelOf(categories, p.category)],
      ['formato', `${labelOf(formats, p.format)}${p.collab ? ' · collab' : ''}`],
      ['ano', p.date.slice(0, 4)],
      p.duration && ['duração', p.duration],
      ...p.credits.map((c) => [c.role, c.who]),
      p.music && ['trilha', p.music],
      p.media.carouselNote && ['carrossel', p.media.carouselNote],
      p.sound && ['som', p.sound],
    ].filter(Boolean);

    mount(this.$('[data-panel]'), html`
      <h2 class="viewer__title" id="viewer-title">${p.title}</h2>
      ${p.caption.length ? html`<div class="viewer__caption">${p.caption.map((c) => html`<p>${c}</p>`)}</div>` : ''}
      <dl class="viewer__meta mono">
        ${meta.map(([k, v]) => html`<dt>${k}</dt><dd>${isPlaceholder(v) ? txt(v) : v}</dd>`)}
      </dl>
      <p class="viewer__desc"><span class="mono">o que se vê · </span>${p.alt}</p>
      <button class="btn" type="button" data-quote="${p.id}">quero algo nessa linha ${icons.arrow}</button>
      <p class="mono viewer__keys">← → navegar · espaço pausar · m som · esc fechar</p>
    `);
  }

  renderControls() {
    const playing = !this.video.paused;
    const play = this.$('[data-role="play"]');
    play.innerHTML = String(playing ? icons.pause : icons.play);
    play.setAttribute('aria-label', playing ? 'pausar vídeo' : 'reproduzir vídeo');
    const sound = this.$('[data-role="sound"]');
    sound.innerHTML = String(this.media.soundOn ? icons.soundOn : icons.soundOff);
    sound.setAttribute('aria-pressed', String(this.media.soundOn));
    sound.setAttribute('aria-label', this.media.soundOn ? 'desligar o som' : 'ligar o som');
  }

  renderTime() {
    const { currentTime, duration } = this.video;
    const pos = Number.isFinite(duration) && duration > 0 ? (currentTime / duration) * 1000 : 0;
    this.seek.value = String(Math.round(pos));
    this.seek.setAttribute('aria-valuetext', timecode(currentTime));
    this.$('[data-time]').textContent = `${timecode(currentTime)} / ${timecode(duration)}`;
  }

  togglePlay() {
    if (!this.current?.media.sources.length) return;
    if (this.video.paused) this.video.play().catch(() => {});
    else this.video.pause();
  }

  close({ toHash } = {}) {
    if (!this.dialog.open) return;
    this.closeHash = toHash;
    this.dialog.close();
  }

  afterClose() {
    this.video.pause();
    this.video.removeAttribute('src');
    this.video.replaceChildren();
    this.video.load();
    this.media.suspend(false);
    if (this.closeHash) {
      location.hash = this.closeHash;
    } else {
      history.replaceState(null, '', this.prevHash || location.pathname + location.search);
      if (this.trigger?.isConnected) this.trigger.focus({ preventScroll: true });
    }
    this.closeHash = undefined;
  }
}
