import { html } from '../utils/dom.js';

/** Barra fixa de rascunho: conta e destaca os placeholders. Desligue com site.draft = false. */
export function mountDraftBar(el) {
  const count = () => document.querySelectorAll('[data-placeholder], [data-placeholder-media]').length;
  el.className = 'draft-bar';
  el.innerHTML = String(html`<button type="button" aria-pressed="false">rascunho · <span data-n></span> placeholders · destacar</button>`);
  const btn = el.querySelector('button');
  const refresh = () => { el.querySelector('[data-n]').textContent = count(); };
  btn.addEventListener('click', () => {
    const on = document.documentElement.classList.toggle('show-placeholders');
    btn.setAttribute('aria-pressed', String(on));
  });
  refresh();
  return { refresh };
}
