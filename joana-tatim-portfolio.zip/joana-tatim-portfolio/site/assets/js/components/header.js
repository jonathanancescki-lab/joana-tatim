import { html } from '../utils/dom.js';

export function Header({ site }) {
  return html`<a class="wordmark" href="#inicio" aria-label="${site.name}, início">${site.name}</a>
  <nav class="site-nav" aria-label="principal">
    <ul>
      <li><a href="#trabalhos" data-nav="inicio">trabalhos</a></li>
      <li><a href="#processo" data-nav="inicio">processo</a></li>
      <li><a href="#contato" data-nav="contato">contato</a></li>
    </ul>
  </nav>
  <div class="header-tools">
    <button class="toggle" type="button" data-toggle="sound" aria-pressed="false">
      <span class="toggle__dot" aria-hidden="true"></span><span class="toggle__label">som</span><span class="toggle__state" aria-hidden="true">off</span>
      <span class="visually-hidden">dos vídeos</span>
    </button>
    <button class="toggle" type="button" data-toggle="motion" aria-pressed="true">
      <span class="toggle__dot" aria-hidden="true"></span><span class="toggle__label">movimento</span><span class="toggle__state" aria-hidden="true">on</span>
      <span class="visually-hidden">reprodução automática</span>
    </button>
    <a class="btn header-cta" href="#contato">pedir orçamento</a>
  </div>`;
}

/** Liga os botões globais ao MediaController e mantém o estado visual em dia. */
export function bindHeader(el, media) {
  const sound = el.querySelector('[data-toggle="sound"]');
  const motion = el.querySelector('[data-toggle="motion"]');
  const render = () => {
    sound.setAttribute('aria-pressed', String(media.soundOn));
    sound.querySelector('.toggle__state').textContent = media.soundOn ? 'on' : 'off';
    motion.setAttribute('aria-pressed', String(media.motionOn));
    motion.querySelector('.toggle__state').textContent = media.motionOn ? 'on' : 'off';
  };
  sound.addEventListener('click', () => media.setSound(!media.soundOn));
  motion.addEventListener('click', () => media.setMotion(!media.motionOn));
  media.addEventListener('change', render);
  render();
}

export function setCurrentNav(el, view) {
  el.querySelectorAll('[data-nav]').forEach((a) => {
    if (view === 'contato' && a.dataset.nav === 'contato') a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  });
}
