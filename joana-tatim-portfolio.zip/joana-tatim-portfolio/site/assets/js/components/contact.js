import { html, txt } from '../utils/dom.js';
import { icons } from '../utils/icons.js';

/**
 * Página de orçamento.
 * O site é estático: o formulário não envia nada sozinho. Ao enviar, ele monta a mensagem
 * e oferece "abrir no e-mail" (mailto) e "copiar". Para envio direto, ligue um serviço de
 * formulários (ver README › Formulário).
 */
export function Contact({ site, categories, projects }) {
  const c = site.contact;
  return html`<section class="contact wrap" aria-labelledby="contato-title">
    <div class="contact__intro">
      <p class="mono soft">contato · orçamentos</p>
      <h1 class="contact__title" id="contato-title" tabindex="-1">orçamentos para marcas</h1>
      <p class="contact__text">conte sobre o produto e o que você quer que as pessoas sintam ao assistir. quanto mais concreto o briefing, mais precisa a proposta.</p>

      <div>
        <p class="mono soft" style="margin-bottom: var(--space-3)">ajuda incluir</p>
        <ul class="brief-list">
          <li>o produto e a textura, o som ou o gesto que ele tem de único</li>
          <li>onde o vídeo vai rodar: reels, anúncio, site ou ponto de venda</li>
          <li>quantos vídeos e em quais formatos</li>
          <li>prazo de entrega e data de lançamento</li>
          <li>referências de que a marca gosta</li>
        </ul>
      </div>

      <ul class="channels">
        <li><span class="mono soft">e-mail</span><a href="mailto:${c.email}">${c.email}</a></li>
        <li><span class="mono soft">instagram</span><a href="${c.instagram.url}" rel="noopener">${c.instagram.handle}</a></li>
        <li><span class="mono soft">threads</span><a href="${c.threads.url}" rel="noopener">${c.threads.handle}</a></li>
        <li><span class="mono soft">whatsapp</span><span>${txt(c.whatsapp)}</span></li>
        <li><span class="mono soft">resposta</span><span>${txt(c.responseTime)}</span></li>
        <li><span class="mono soft">base</span><span>${c.base} · ${txt(c.city)}</span></li>
      </ul>
    </div>

    <form class="form" id="quote-form" novalidate aria-describedby="form-note">
      <div class="field">
        <label for="f-name">nome <span class="req" aria-hidden="true">*</span></label>
        <input id="f-name" name="nome" type="text" autocomplete="name" required aria-describedby="e-name">
        <p class="field__error" id="e-name" aria-live="polite"></p>
      </div>
      <div class="field">
        <label for="f-email">e-mail <span class="req" aria-hidden="true">*</span></label>
        <input id="f-email" name="email" type="email" autocomplete="email" required aria-describedby="e-email">
        <p class="field__error" id="e-email" aria-live="polite"></p>
      </div>
      <div class="field">
        <label for="f-brand">marca ou empresa <span class="req" aria-hidden="true">*</span></label>
        <input id="f-brand" name="marca" type="text" autocomplete="organization" required aria-describedby="e-brand">
        <p class="field__error" id="e-brand" aria-live="polite"></p>
      </div>
      <div class="field">
        <label for="f-link">site ou instagram da marca</label>
        <input id="f-link" name="link" type="text" inputmode="url" placeholder="@marca ou site">
      </div>
      <div class="field">
        <label for="f-category">categoria do produto</label>
        <select id="f-category" name="categoria">
          <option value="">selecione</option>
          ${categories.filter((x) => x.id !== 'autoral').map((x) => html`<option value="${x.label}">${x.label}</option>`)}
          <option value="outra">outra</option>
        </select>
      </div>
      <div class="field">
        <label for="f-date">data desejada de entrega</label>
        <input id="f-date" name="prazo" type="date">
      </div>
      <fieldset class="field field--full checks">
        <legend>formatos de interesse</legend>
        ${['vídeo sensorial (reels 9:16)', 'carrossel de bastidores', 'stills / fotos', 'outro'].map((f, i) => html`<label class="chip"><input type="checkbox" name="formatos" value="${f}" id="f-fmt-${i}"><span>${f}</span></label>`)}
      </fieldset>
      <div class="field">
        <label for="f-qty">quantidade de vídeos</label>
        <input id="f-qty" name="quantidade" type="number" min="1" step="1" inputmode="numeric">
      </div>
      <div class="field">
        <label for="f-budget">verba estimada (opcional)</label>
        <input id="f-budget" name="verba" type="text" placeholder="faixa aproximada">
      </div>
      <div class="field field--full">
        <label for="f-ref">referência no portfólio</label>
        <select id="f-ref" name="referencia">
          <option value="">nenhuma em especial</option>
          ${projects.map((p) => html`<option value="${p.id}">${p.number} · ${p.title}</option>`)}
        </select>
      </div>
      <div class="field field--full">
        <label for="f-msg">sobre o projeto <span class="req" aria-hidden="true">*</span></label>
        <textarea id="f-msg" name="mensagem" required aria-describedby="e-msg"></textarea>
        <p class="field__error" id="e-msg" aria-live="polite"></p>
      </div>
      <div class="form__footer">
        <button class="btn" type="submit">preparar mensagem ${icons.arrow}</button>
        <p class="mono form__note" id="form-note">* obrigatório. o site monta a mensagem e você envia pelo seu e-mail ou copia.</p>
      </div>
      <div class="result" data-result hidden tabindex="-1" aria-labelledby="result-title">
        <p class="result__title" id="result-title">sua mensagem está pronta para envio</p>
        <p>envie para <strong>${c.email}</strong>. o botão abre seu app de e-mail com tudo preenchido. se ele não abrir, copie o texto abaixo.</p>
        <label class="visually-hidden" for="f-output">mensagem pronta</label>
        <textarea id="f-output" readonly data-output></textarea>
        <div class="result__actions">
          <a class="btn" data-mailto href="mailto:${c.email}">abrir no e-mail ${icons.arrow}</a>
          <button class="btn btn--ghost" type="button" data-copy>copiar mensagem</button>
          <span class="mono soft" role="status" data-copy-status></span>
        </div>
      </div>
    </form>
  </section>`;
}

const MESSAGES = {
  valueMissing: 'preencha este campo.',
  typeMismatch: 'confira o formato do e-mail.',
};

export function bindContact(el, { site, byId }) {
  const form = el.querySelector('#quote-form');
  const result = form.querySelector('[data-result]');
  const output = form.querySelector('[data-output]');
  const mailto = form.querySelector('[data-mailto]');
  const copyStatus = form.querySelector('[data-copy-status]');

  const validate = () => {
    let first = null;
    form.querySelectorAll('[required]').forEach((input) => {
      const err = form.querySelector(`#${input.getAttribute('aria-describedby')}`);
      const v = input.validity;
      const msg = v.valueMissing ? MESSAGES.valueMissing : v.typeMismatch ? MESSAGES.typeMismatch : '';
      err.textContent = msg;
      input.setAttribute('aria-invalid', String(!!msg));
      if (msg && !first) first = input;
    });
    first?.focus();
    return !first;
  };

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!validate()) return;
    const d = new FormData(form);
    const formats = d.getAll('formatos');
    const ref = byId(d.get('referencia'));
    const opt = (label, value) => (value ? `${label}: ${value}` : null);
    const date = d.get('prazo') ? d.get('prazo').split('-').reverse().join('/') : '';
    const lines = [
      'olá, joana!',
      '',
      `nome: ${d.get('nome')}`,
      `marca: ${d.get('marca')}`,
      `e-mail: ${d.get('email')}`,
      opt('site/instagram', d.get('link')),
      opt('categoria', d.get('categoria')),
      opt('formatos', formats.join(', ')),
      opt('quantidade de vídeos', d.get('quantidade')),
      opt('entrega desejada', date),
      opt('verba estimada', d.get('verba')),
      opt('referência no portfólio', ref ? `${ref.number} · ${ref.title}` : ''),
      '',
      d.get('mensagem'),
    ].filter((l) => l !== null);
    const body = lines.join('\n');
    const subject = `orçamento · ${d.get('marca')}${formats.length ? ` · ${formats[0]}` : ''}`;
    output.value = body;
    mailto.href = `mailto:${site.contact.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    copyStatus.textContent = '';
    result.hidden = false;
    result.focus();
  });

  form.querySelector('[data-copy]').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(output.value);
      copyStatus.textContent = 'copiado.';
    } catch {
      output.select();
      copyStatus.textContent = 'selecionei o texto. use ctrl/cmd + c para copiar.';
    }
  });

  form.querySelectorAll('[required]').forEach((input) =>
    input.addEventListener('input', () => {
      if (input.getAttribute('aria-invalid') === 'true' && input.validity.valid) {
        input.setAttribute('aria-invalid', 'false');
        form.querySelector(`#${input.getAttribute('aria-describedby')}`).textContent = '';
      }
    }),
  );

  return {
    /** Pré-seleciona um projeto como referência (vindo do viewer). */
    prefill(projectId) {
      const select = form.querySelector('#f-ref');
      if (byId(projectId)) select.value = projectId;
    },
  };
}
