import { html, txt } from '../utils/dom.js';

export function Footer({ site }) {
  const c = site.contact;
  return html`<div class="site-footer wrap">
    <div class="site-footer__brand">
      <p class="site-footer__name">${site.name}</p>
      <p class="mono soft">${site.eyebrow}</p>
    </div>
    <ul class="mono">
      <li><a href="mailto:${c.email}">${c.email}</a></li>
      <li><a href="${c.instagram.url}" rel="noopener">instagram ${c.instagram.handle}</a></li>
      <li><a href="${c.threads.url}" rel="noopener">threads ${c.threads.handle}</a></li>
    </ul>
    <ul class="mono soft">
      <li><a href="#contato">pedir orçamento</a></li>
      <li>© ${new Date().getFullYear()} ${site.name}</li>
      <li>${c.base}</li>
    </ul>
  </div>`;
}
