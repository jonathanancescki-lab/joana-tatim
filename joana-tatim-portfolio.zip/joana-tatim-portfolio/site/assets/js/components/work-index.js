import { html, ph, storage } from '../utils/dom.js';
import { labelOf } from '../data/taxonomy.js';
import { MediaFrame } from './media-frame.js';

const ALL = 'todos';

const Chip = (name, value, label, checked) => html`<label class="chip">
  <input type="radio" name="${name}" value="${value}"${checked ? html` checked` : ''}>
  <span>${label} <span class="chip__count" data-count="${value}"></span></span>
</label>`;

function Card(p, categories) {
  return html`<li class="grid__item${p.size === 'large' ? ' grid__item--large' : ''}" data-category="${p.category}" data-format="${p.format}" style="view-transition-name: card-${p.id}">
    <button class="card" type="button" data-open="${p.id}" data-hover-root>
      ${MediaFrame(p, { as: 'span', autoplay: 'hover', controls: false, alt: '', sizes: p.size === 'large' ? '(max-width: 560px) 100vw, 40vw' : '(max-width: 560px) 50vw, 22vw' })}
      <span class="card__meta">
        <span class="mono card__num">${p.number}</span>
        <span class="card__title">${p.title}</span>
        <span class="mono card__brand">${p.brands.length ? p.brands.join(' ') : 'projeto autoral'} · ${p.format === 'bastidores' ? 'bastidores' : labelOf(categories, p.category)}</span>
      </span>
    </button>
  </li>`;
}

export function WorkIndex({ projects, categories, formats }) {
  const brands = [...new Set(projects.flatMap((p) => p.brands))];
  return html`<section class="work-index wrap" id="trabalhos" aria-labelledby="trabalhos-title">
    <header class="section-head">
      <p class="mono section-head__label">índice · ${projects.length} projetos</p>
      <h2 class="section-head__title" id="trabalhos-title">trabalhos por tipo de marca e formato</h2>
    </header>

    <form class="filters" aria-label="filtrar trabalhos" data-filters>
      <fieldset>
        <legend>categoria de marca</legend>
        ${Chip('categoria', ALL, 'todas', true)}
        ${categories.map((c) => Chip('categoria', c.id, c.label, false))}
      </fieldset>
      <fieldset>
        <legend>formato</legend>
        ${Chip('formato', ALL, 'todos', true)}
        ${formats.map((f) => Chip('formato', f.id, f.label, false))}
      </fieldset>
      <p class="mono filters__status" role="status" aria-live="polite" data-status></p>
    </form>

    <ul class="grid" data-grid>${projects.map((p) => Card(p, categories))}</ul>

    <div class="brands">
      <p class="mono soft">marcas nos trabalhos</p>
      <div>
        <ul class="brands__list">${brands.map((b) => html`<li><a class="mono" href="https://www.instagram.com/${b.slice(1)}/" rel="noopener">${b}</a></li>`)}</ul>
        <p class="mono soft" style="margin-top: var(--space-3)">${ph('confirmar com cada marca a autorização para exibir o trabalho no portfólio')}</p>
      </div>
    </div>
  </section>`;
}

/** Filtros: mostra/oculta itens, atualiza contagens e anuncia o resultado. */
export function bindWorkIndex(el, { projects, media }) {
  const form = el.querySelector('[data-filters]');
  const items = [...el.querySelectorAll('.grid__item')];
  const status = el.querySelector('[data-status]');

  const saved = (() => { try { return JSON.parse(storage.get('jt-filters') || 'null'); } catch { return null; } })();
  if (saved) {
    form.querySelector(`input[name="categoria"][value="${saved.cat}"]`)?.click();
    form.querySelector(`input[name="formato"][value="${saved.fmt}"]`)?.click();
  }

  const apply = (animate) => {
    const cat = form.categoria.value;
    const fmt = form.formato.value;
    storage.set('jt-filters', JSON.stringify({ cat, fmt }));

    const update = () => {
      let shown = 0;
      items.forEach((li) => {
        const ok = (cat === ALL || li.dataset.category === cat) && (fmt === ALL || li.dataset.format === fmt);
        li.hidden = !ok;
        if (ok) shown += 1;
      });
      form.querySelectorAll('[data-count]').forEach((n) => {
        const v = n.dataset.count;
        const input = n.closest('label').querySelector('input');
        const count = input.name === 'categoria'
          ? projects.filter((p) => (v === ALL || p.category === v) && (fmt === ALL || p.format === fmt)).length
          : projects.filter((p) => (v === ALL || p.format === v) && (cat === ALL || p.category === cat)).length;
        n.textContent = count;
        input.disabled = count === 0 && !input.checked;
      });
      status.textContent = `${shown} de ${projects.length} projetos`;
    };

    if (animate && document.startViewTransition && media.motionOn) document.startViewTransition(update);
    else update();
  };

  form.addEventListener('change', () => apply(true));
  form.addEventListener('submit', (e) => e.preventDefault());
  apply(false);
}
