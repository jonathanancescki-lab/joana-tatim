import { html } from '../utils/dom.js';
import { icons } from '../utils/icons.js';
import { labelOf, categories } from '../data/taxonomy.js';
import { MediaFrame } from './media-frame.js';

/** Sequência de projetos em destaque, cada um em quase tela cheia sobre a própria cor. */
export function Featured({ projects }) {
  const total = String(projects.length).padStart(2, '0');
  return html`<section class="features" id="destaques" aria-labelledby="destaques-title">
    <h2 class="visually-hidden" id="destaques-title">trabalhos em destaque</h2>
    ${projects.map((p, i) => html`<article class="feature" style="--tint: ${p.tint}" aria-labelledby="f-${p.id}">
      <div class="feature__frame">${MediaFrame(p, { sizes: '(max-width: 820px) 100vw, 50vw' })}</div>
      <div class="feature__note">
        <p class="mono feature__index"><span>${String(i + 1).padStart(2, '0')} / ${total}</span><span>${labelOf(categories, p.category)}</span><span>${p.date.slice(0, 4)}</span></p>
        <h3 class="feature__title" id="f-${p.id}">${p.title}</h3>
        ${p.brands.length ? html`<p class="feature__brand">${p.brands.join('  ')}${p.collab ? ' · collab' : ''}</p>` : ''}
        ${p.caption.length ? html`<div class="feature__caption">${p.caption.map((c) => html`<p>${c}</p>`)}</div>` : ''}
        <button class="link-arrow" type="button" data-open="${p.id}">ver projeto ${icons.arrow}</button>
      </div>
    </article>`)}
  </section>`;
}
