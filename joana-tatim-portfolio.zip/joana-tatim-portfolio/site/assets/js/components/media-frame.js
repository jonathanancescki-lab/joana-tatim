import { html, raw } from '../utils/dom.js';
import { icons } from '../utils/icons.js';

/**
 * Quadro de vídeo com pôster responsivo.
 * O <img> carrega o pôster (lazy, srcset) e leva o texto alternativo;
 * o <video> só recebe src via MediaController quando se aproxima da tela.
 *
 * @param {object} p        projeto
 * @param {object} opts
 *   as        'div' | 'span' (span dentro de <button>)
 *   autoplay  'visible' | 'hover'
 *   controls  mostra botões de play/pausa e som
 *   eager     pôster com prioridade alta (primeira dobra)
 *   alt       sobrescreve o texto alternativo ('' quando o contexto já nomeia o projeto)
 *   sizes     atributo sizes do pôster
 */
export function MediaFrame(p, { as = 'div', autoplay = 'visible', controls = true, eager = false, alt = p.alt, sizes = '(max-width: 860px) 100vw, 50vw' } = {}) {
  const hasVideo = p.media.sources.length > 0;
  const tag = as === 'span' ? 'span' : 'div';
  const base = p.media.poster;

  const tracks = (p.tracks || []).map(
    (t, i) => html`<track kind="${t.kind || 'captions'}" src="${t.src}" srclang="${t.srclang || 'pt-BR'}" label="${t.label || 'português'}"${i === 0 ? raw(' default') : ''}>`,
  );

  const video = hasVideo
    ? html`<video class="media-frame__video" muted loop playsinline preload="none" aria-hidden="true" tabindex="-1" width="720" height="960">${p.media.sources.map((s) => html`<source data-src="${s.src}" type="${s.type}">`)}${tracks}</video>`
    : '';

  const tag_ = p.media.placeholder
    ? html`<span class="media-frame__tag">${hasVideo ? 'prévia gerada do print' : 'foto do print'}</span>`
    : '';

  const ctrl = hasVideo && controls
    ? html`<span class="media-frame__controls">
        <button class="icon-btn" type="button" data-role="play" aria-label="reproduzir vídeo">${icons.play}</button>
        <button class="icon-btn" type="button" data-role="sound" aria-pressed="false" aria-label="ligar o som deste vídeo">${icons.soundOff}</button>
      </span>`
    : '';

  return html`<${raw(tag)} class="media-frame" data-media data-autoplay="${autoplay}" data-state="idle" style="--tint: ${p.tint}"${hasVideo ? raw(' data-has-video') : ''}${p.media.placeholder ? raw(' data-placeholder-media') : ''}>
    <img class="media-frame__poster" src="${base}-900.webp" srcset="${base}-450.webp 450w, ${base}-900.webp 900w" sizes="${sizes}" width="900" height="1200" alt="${alt}" loading="${eager ? 'eager' : 'lazy'}" decoding="async"${eager ? raw(' fetchpriority="high"') : ''}>
    ${video}${tag_}${ctrl}
  </${raw(tag)}>`;
}
