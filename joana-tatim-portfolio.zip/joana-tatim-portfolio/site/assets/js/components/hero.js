import { html, txt } from '../utils/dom.js';
import { icons } from '../utils/icons.js';
import { MediaFrame } from './media-frame.js';

export function Hero({ site, project }) {
  const { lede } = site;
  return html`<section class="hero wrap" id="inicio" aria-labelledby="hero-title">
    <div class="hero__text">
      <p class="mono hero__eyebrow">${site.eyebrow}</p>
      <h1 class="hero__title" id="hero-title" tabindex="-1">${site.name}</h1>
      <p class="hero__lede">${lede.first} ${lede.second} <em>${lede.emphasis}</em>.</p>
      <div class="hero__actions">
        <a class="btn" href="#contato">pedir orçamento ${icons.arrow}</a>
        <a class="btn btn--ghost" href="#trabalhos">ver trabalhos ${icons.arrowDown}</a>
      </div>
      <p class="mono hero__hint">${icons.headphones}<span>${site.listenHint}</span></p>
    </div>
    <figure class="hero__frame">
      ${MediaFrame(project, { eager: true, sizes: '(max-width: 860px) 100vw, 45vw' })}
      <figcaption class="mono hero__caption">
        <span>${txt(site.reel.label)}</span>
        <button class="link-arrow" type="button" data-open="${project.id}">${project.title} ${icons.arrow}</button>
      </figcaption>
    </figure>
  </section>`;
}
