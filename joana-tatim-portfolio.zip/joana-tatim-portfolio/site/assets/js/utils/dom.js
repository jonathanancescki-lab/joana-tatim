/**
 * Helpers mínimos de template. `html` escapa toda interpolação,
 * exceto valores já marcados como SafeHTML (componentes aninhados).
 */
class SafeHTML {
  constructor(value) { this.value = value; }
  toString() { return this.value; }
}

const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export const escape = (s) => String(s).replace(/[&<>"']/g, (c) => ESC[c]);

const serialize = (v) => {
  if (v == null || v === false) return '';
  if (v instanceof SafeHTML) return v.value;
  if (Array.isArray(v)) return v.map(serialize).join('');
  return escape(v);
};

export const html = (strings, ...values) =>
  new SafeHTML(strings.reduce((out, s, i) => out + s + (i < values.length ? serialize(values[i]) : ''), ''));

export const raw = (s) => new SafeHTML(String(s));

export const mount = (target, content) => {
  const el = typeof target === 'string' ? document.querySelector(target) : target;
  if (el) el.innerHTML = String(content);
  return el;
};

/** Placeholder visível para dado que ainda não foi fornecido. */
export const ph = (text) => html`<span class="ph" data-placeholder>[${text}]</span>`;

/** Renderiza um valor de conteúdo: string normal ou { ph: '...' } para placeholder. */
export const txt = (value) => (value && typeof value === 'object' && 'ph' in value ? ph(value.ph) : value);

export const isPlaceholder = (value) => !!(value && typeof value === 'object' && 'ph' in value);

export const qs = (sel, root = document) => root.querySelector(sel);
export const qsa = (sel, root = document) => [...root.querySelectorAll(sel)];

export const timecode = (sec) => {
  if (!Number.isFinite(sec)) return '00:00';
  const s = Math.max(0, Math.floor(sec));
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
};

/** Mistura duas cores hex (t = peso de a). */
export const mixHex = (a, b, t) => {
  const pa = a.match(/\w\w/g).map((h) => parseInt(h, 16));
  const pb = b.match(/\w\w/g).map((h) => parseInt(h, 16));
  return '#' + pa.map((c, i) => Math.round(c * t + pb[i] * (1 - t)).toString(16).padStart(2, '0')).join('');
};

/** Luminância relativa (WCAG) de uma cor hex. */
export const luminance = (hex) => {
  const [r, g, b] = hex.match(/\w\w/g).map((h) => {
    const c = parseInt(h, 16) / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
};

export const storage = {
  get(key) { try { return sessionStorage.getItem(key); } catch { return null; } },
  set(key, value) { try { sessionStorage.setItem(key, value); } catch { /* sem storage: segue sem lembrar */ } },
};
