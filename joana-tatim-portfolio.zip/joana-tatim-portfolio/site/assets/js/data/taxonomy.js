/** Categorias de marca e formatos de projeto usados nos filtros. */
export const categories = [
  { id: 'beleza', label: 'beleza & skincare' },
  { id: 'bebidas', label: 'bebidas & café' },
  { id: 'alimentos', label: 'alimentos & suplementos' },
  { id: 'acessorios', label: 'moda & acessórios' },
  { id: 'autoral', label: 'autoral' },
];

export const formats = [
  { id: 'video', label: 'vídeo sensorial' },
  { id: 'bastidores', label: 'bastidores' },
];

export const labelOf = (list, id) => list.find((x) => x.id === id)?.label ?? id;
