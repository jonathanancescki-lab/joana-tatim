/**
 * Projetos do portfólio.
 *
 * FONTE: prints do Instagram @joanatatiim enviados pela Joana (legendas, marcas marcadas,
 * créditos e datas dos posts). Nada além disso foi inferido sobre as marcas.
 *
 * Campos
 *  id          slug usado no link direto (#projeto-<id>)
 *  title       primeira linha da legenda original
 *  caption     linhas seguintes da legenda original (ou da marca, nos posts em collab)
 *  brands      perfis marcados no post
 *  category    ver data/taxonomy.js
 *  format      'video' (reel sensorial) ou 'bastidores' (carrossel de fotos)
 *  collab      post publicado em parceria com o perfil da marca
 *  date        data do post (AAAA-MM-DD)
 *  duration    duração do vídeo, quando informada na legenda
 *  credits     créditos citados na legenda
 *  alt         descrição visual do quadro (texto alternativo)
 *  sound       descrição do som para acessibilidade, a preencher pela Joana
 *  tint        cor ambiente amostrada do quadro (usada no fundo das seções e do viewer)
 *  media       pôster e fontes de vídeo. `placeholder: true` = prévia gerada a partir do
 *              print; substituir pelos arquivos originais (ver README › Vídeos).
 *  tracks      legendas WebVTT, obrigatórias se houver fala
 *  size        'large' ocupa 2 colunas na grade (ritmo visual)
 */

const poster = (id) => `media/posters/${id}`;
const preview = (id) => [
  { src: `media/video/${id}-preview.webm`, type: 'video/webm; codecs="vp9, opus"' },
  { src: `media/video/${id}-preview.mp4`, type: 'video/mp4' },
];
const SOUND_TODO = { ph: 'descrição do som, ex.: creme sendo espatulado, estalo do pó' };

export const projects = [
  {
    id: 'materia-prima-liquido',
    title: 'matéria-prima em estado líquido',
    caption: [],
    brands: ['@biancaaccessory'],
    category: 'acessorios',
    format: 'video',
    collab: false,
    date: '2026-10-16',
    credits: [
      { role: 'modelos e cabelos', who: '@tn.talya, @du.mrtns' },
      { role: 'fotografia', who: '@luisadfotografia' },
    ],
    alt: 'Mecha de cabelo castanho escuro, brilhante, curvando-se em S sobre fundo branco.',
    sound: SOUND_TODO,
    tint: '#cdc8cb',
    media: { poster: poster('materia-prima-liquido'), sources: preview('materia-prima-liquido'), placeholder: true },
    tracks: [],
    size: 'large',
  },
  {
    id: 'menta-gelada',
    title: 'a menta mais gelada',
    caption: ['para os melhores tererés'],
    brands: ['@somos.goat'],
    category: 'bebidas',
    format: 'video',
    collab: false,
    date: '2026-10-08',
    credits: [],
    alt: 'Erva-mate e folhas de menta picadas em close, com uma nuvem de pó verde subindo.',
    sound: SOUND_TODO,
    tint: '#78764b',
    media: { poster: poster('menta-gelada'), sources: preview('menta-gelada'), placeholder: true },
    tracks: [],
  },
  {
    id: 'laboratorio-hidrabene',
    title: 'dentro do laboratório',
    caption: ['por trás das câmeras de muitos experimentos e usando as vidraçarias químicas com zero rigor científico!!!'],
    brands: ['@hidrabene'],
    category: 'beleza',
    format: 'bastidores',
    collab: false,
    date: '2026-10-05',
    credits: [],
    alt: 'Mesa branca vista de cima com séruns Hidrabene, béqueres com líquido rosa e azul, prancheta e recortes de pele.',
    sound: null,
    tint: '#a8a9b5',
    media: { poster: poster('laboratorio-hidrabene'), sources: [], placeholder: true, carouselNote: { ph: 'demais fotos do carrossel (10 imagens)' } },
    tracks: [],
  },
  {
    id: 'k-beauty-hidrabene',
    title: 'o próximo capítulo da k-beauty',
    caption: ['os três k-séruns que você já conhece estão prestes a ganhar uma nova potência.'],
    brands: ['@hidrabene'],
    category: 'beleza',
    format: 'video',
    collab: true,
    date: '2026-09-25',
    credits: [],
    alt: 'Gotas de sérum azul descendo em câmera lenta dentro de um líquido transparente.',
    sound: SOUND_TODO,
    tint: '#c9d7ea',
    media: { poster: poster('k-beauty-hidrabene'), sources: preview('k-beauty-hidrabene'), placeholder: true },
    tracks: [],
  },
  {
    id: 'bastidores-benvi',
    title: 'por trás das câmeras, benvi',
    caption: ['procurar folhas certas e escolher a semente de cumaru mais bonita e fotogênica'],
    brands: ['@benvinatural'],
    category: 'beleza',
    format: 'bastidores',
    collab: true,
    date: '2026-09-21',
    credits: [],
    alt: 'Espátula de bambu com a marca benvi gravada, mergulhada em creme claro com mel e sementes moídas.',
    sound: null,
    tint: '#baa086',
    media: { poster: poster('bastidores-benvi'), sources: [], placeholder: true, carouselNote: { ph: 'demais fotos do carrossel (10 imagens)' } },
    tracks: [],
  },
  {
    id: 'bioativos-amazonia',
    title: 'sensorial com bioativos da amazônia',
    caption: ['mousse ultra hidratante da @benvinatural', '(pensamentos intrusivos: é de passar na pele, não de comer!)'],
    brands: ['@benvinatural'],
    category: 'beleza',
    format: 'video',
    collab: false,
    date: '2026-09-20',
    credits: [],
    alt: 'Semente de cumaru escura suspensa sobre fundo claro, com um fio de mel dourado escorrendo.',
    sound: SOUND_TODO,
    tint: '#e8e3e0',
    media: { poster: poster('bioativos-amazonia'), sources: preview('bioativos-amazonia'), placeholder: true },
    tracks: [],
  },
  {
    id: 'sono-quentinho',
    title: 'para uma noite de sono mais quentinha',
    caption: ['contando carneirinhos de chocolate com o mais gostoso good sleep'],
    brands: ['@suplemind'],
    category: 'alimentos',
    format: 'video',
    collab: false,
    date: '2026-07-09',
    credits: [],
    alt: 'Pó de chocolate em close, com uma colher dosadora afundada e marcas de textura na superfície.',
    sound: SOUND_TODO,
    tint: '#5c4740',
    media: { poster: poster('sono-quentinho'), sources: preview('sono-quentinho'), placeholder: true },
    tracks: [],
  },
  {
    id: 'banho-jellycious',
    title: 'para um banho mais jellycious',
    caption: [],
    brands: ['@goodmood.byalva', '@alvapersonalcare'],
    category: 'beleza',
    format: 'video',
    collab: false,
    date: '2026-06-23',
    credits: [],
    alt: 'Embalagem azul-turquesa do sabonete good mood boiando em espuma branca.',
    sound: SOUND_TODO,
    tint: '#cccfda',
    media: { poster: poster('banho-jellycious'), sources: preview('banho-jellycious'), placeholder: true },
    tracks: [],
  },
  {
    id: 'bastidores-gioi',
    title: 'por trás das câmeras, giói',
    caption: [
      'um sensorial de todos cafés que tomamos ao longo do dia.',
      'quantidades exageradas de café foram consumidas para a produção desse vídeo',
    ],
    brands: ['@gioicafe'],
    category: 'bebidas',
    format: 'bastidores',
    collab: true,
    date: '2026-06-02',
    credits: [],
    alt: 'Leite sendo despejado em um copo de café gelado, formando ondas claras entre os cubos de gelo.',
    sound: null,
    tint: '#927a70',
    media: { poster: poster('bastidores-gioi'), sources: [], placeholder: true, carouselNote: { ph: 'demais fotos do carrossel (14 imagens)' } },
    tracks: [],
  },
  {
    id: 'cafes-do-dia',
    title: 'os cafés de cada momento do dia',
    caption: [
      'no café da manhã, se arrumando, depois do almoço, antes do trabalho, durante o trabalho, pré treino.',
      'todos eles com @gioicafe',
    ],
    brands: ['@gioicafe'],
    category: 'bebidas',
    format: 'video',
    collab: true,
    date: '2026-05-26',
    credits: [],
    alt: 'Mãos despejam leite de uma leiteira de inox numa xícara de café, ao lado de um croissant em bandeja prateada.',
    sound: SOUND_TODO,
    tint: '#9d8e91',
    media: { poster: poster('cafes-do-dia'), sources: preview('cafes-do-dia'), placeholder: true },
    tracks: [],
  },
  {
    id: 'vontade-de-creme',
    title: 'sim, você também vai ter vontade de usar o creme',
    caption: [],
    brands: ['@lecieza.br'],
    category: 'beleza',
    format: 'video',
    collab: false,
    date: '2026-03-31',
    credits: [],
    alt: 'Dedos retiram creme branco de um pote aberto do creme hidratante intenso Lecieza.',
    sound: SOUND_TODO,
    tint: '#d1cdd3',
    media: { poster: poster('vontade-de-creme'), sources: preview('vontade-de-creme'), placeholder: true },
    tracks: [],
  },
  {
    id: 'rose-inspired',
    title: 'rosé inspired',
    caption: ['floral e elegante', '(não houve desperdício de vinho nessa produção)'],
    brands: [],
    category: 'autoral',
    format: 'video',
    collab: false,
    date: '2026-03-05',
    credits: [],
    // O post original usa uma faixa musical licenciada no Instagram; confirmar o áudio para o site.
    music: { ph: 'confirmar licença da trilha para uso fora do Instagram' },
    alt: 'Pétalas cor-de-rosa em macro, cobertas de gotas de água.',
    sound: SOUND_TODO,
    tint: '#eda0ac',
    media: { poster: poster('rose-inspired'), sources: preview('rose-inspired'), placeholder: true },
    tracks: [],
    size: 'large',
  },
  {
    id: 'natureza-40s',
    title: 'registro sensorial, 40 segundos de natureza',
    caption: [],
    brands: ['@aloehbeauty'],
    category: 'beleza',
    format: 'video',
    collab: false,
    date: '2026-01-20',
    duration: '00:40',
    credits: [],
    alt: 'Mulher inclina um frasco verde de aloeh sobre a palma da mão, com gotas de água no ar.',
    sound: SOUND_TODO,
    tint: '#b9a28e',
    media: { poster: poster('natureza-40s'), sources: preview('natureza-40s'), placeholder: true },
    tracks: [],
  },
  {
    id: 'sos-new-lips',
    title: 'kit sos new lips',
    caption: ['hidratação, brilho ou cor? com o kit sos new lips da pinkperfect, você não precisa escolher.'],
    brands: ['@pinkperfect_oficial'],
    category: 'beleza',
    format: 'video',
    collab: true,
    date: '2025-05-29',
    credits: [],
    alt: 'Close de lábios com gloss, a ponta do dedo tocando o lábio inferior.',
    sound: SOUND_TODO,
    tint: '#d0b7b4',
    media: { poster: poster('sos-new-lips'), sources: preview('sos-new-lips'), placeholder: true },
    tracks: [],
  },
];

/** Ordem cronológica decrescente (mais recente = 01). */
export const sortedProjects = [...projects]
  .sort((a, b) => b.date.localeCompare(a.date))
  .map((p, i) => ({ ...p, number: String(i + 1).padStart(2, '0') }));

export const byId = (id) => sortedProjects.find((p) => p.id === id);
