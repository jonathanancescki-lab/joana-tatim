/**
 * Conteúdo institucional do site.
 *
 * Convenções:
 *  - { ph: '...' }  → placeholder visível. Dado que a Joana ainda precisa fornecer.
 *  - // FONTE: bio  → retirado do perfil do Instagram (@joanatatiim).
 *  - // COPY SUGERIDA → texto escrito a partir das legendas dela; validar antes de publicar.
 */
export const site = {
  /** true mostra a barra de rascunho que destaca os placeholders. Desligar antes de publicar. */
  draft: true,

  name: 'joana tatim',
  // FONTE: bio ("Artista · conteúdos sensoriais | sensory marketing · brazil")
  eyebrow: 'artista · conteúdos sensoriais · sensory marketing · brazil',

  // COPY SUGERIDA (a expressão em itálico vem da legenda "Matéria-prima em estado líquido")
  lede: {
    first: 'vídeos sensoriais para marcas de beleza, bebidas e alimentos.',
    second: 'textura, som e',
    emphasis: 'matéria-prima em estado líquido',
  },
  // Achado de pesquisa: a experiência sensorial é mais forte com fones de ouvido.
  listenHint: 'melhor com fones. o som começa desligado e você liga quando quiser.',

  /** O reel do topo. Enquanto não houver um corte próprio, usa um projeto como stand-in. */
  reel: {
    projectId: 'materia-prima-liquido',
    label: { ph: 'reel 30–60 s · substituir' },
  },

  featured: ['bioativos-amazonia', 'k-beauty-hidrabene', 'cafes-do-dia', 'sono-quentinho'],

  contact: {
    email: 'contatojoanatatim@gmail.com', // FONTE: bio. Confirmar se é o e-mail comercial.
    instagram: { handle: '@joanatatiim', url: 'https://www.instagram.com/joanatatiim/' },
    threads: { handle: '@joanatatiim', url: 'https://www.threads.com/@joanatatiim' },
    whatsapp: { ph: 'whatsapp comercial' },
    responseTime: { ph: 'prazo de resposta, ex.: até 2 dias úteis' },
    base: 'brazil', // FONTE: bio
    city: { ph: 'cidade-base para gravações presenciais' },
  },

  // COPY SUGERIDA: etapas descritas a partir das legendas de bastidores.
  process: [
    {
      title: 'briefing sensorial',
      text: 'começa pelo produto na mão. qual textura, qual som e qual sensação a marca quer que fique em quem assiste.',
    },
    {
      title: 'matéria-prima',
      text: 'pesquisa de ingredientes, objetos e superfícies. às vezes é procurar as folhas certas e a semente de cumaru mais fotogênica.',
    },
    {
      title: 'set e captação',
      text: 'fundo limpo, luz de estúdio e câmera perto o bastante para a textura virar protagonista.',
    },
    {
      title: 'som e edição',
      text: 'o áudio original faz parte da obra. o creme, o pó, o líquido caindo. a edição segue o tempo da textura.',
    },
  ],

  // Formatos observados nos posts dela (reels com áudio original, carrosséis, collabs).
  formats: [
    'reels verticais 9:16 com áudio original',
    'carrosséis de bastidores da produção',
    'posts em collab com o perfil da marca',
  ],

  about: {
    photo: { ph: 'foto de perfil da joana' },
    bio: { ph: 'bio curta em 2 ou 3 frases: trajetória, desde quando produz vídeo sensorial e formação' },
  },
};
